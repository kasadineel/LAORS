import Link from "next/link"
import { currentUser } from "@clerk/nextjs/server"
import { ensureCore } from "@/lib/ensure-core"
import { prisma } from "@/lib/prisma"

export default async function AnimalsPage() {
  const user = await currentUser()
  if (!user) return null

  const core = await ensureCore({
    clerkUserId: user.id,
    email: user.emailAddresses[0]?.emailAddress ?? "",
    name: [user.firstName, user.lastName].filter(Boolean).join(" ") || null,
  })

  const animals = await prisma.animal.findMany({
    where: { organizationId: core.activeOrganizationId },
    orderBy: { createdAt: "desc" },
  })

  return (
    <main style={{ padding: 24 }}>
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1>Animals</h1>
        <Link href="/dashboard/animals/new">+ Add Animal</Link>
      </header>

      {animals.length === 0 ? (
        <p style={{ marginTop: 16 }}>No animals yet. Add your first one.</p>
      ) : (
        <ul style={{ marginTop: 16, paddingLeft: 18 }}>
          {animals.map((a) => (
            <li key={a.id} style={{ marginBottom: 8 }}>
              <Link href={`/dashboard/animals/${a.id}`}>
                {a.tagNumber ? `#${a.tagNumber}` : "No Tag"}{" "}
                {a.name ? `— ${a.name}` : ""}
                {a.sexClass ? ` (${a.sexClass})` : ""}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </main>
  )
}